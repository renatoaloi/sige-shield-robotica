
class SigeShieldRobotica {
public:
    SigeShieldRobotica();
}