# Rele.ino

Descrição do programa

## Análise do código

- Na função *setup()* ....

```
void setup() {
}
```

> **void setup() {}** é uma função de configuração do código, ela roda uma vez quando o Arduino é ligado. As instruções da função *setup()* ficam dentro de chaves {}.

- Na função *loop* ...

```
void loop() {
}
```

> **void loop() {}** é a função principal do código, ela fica rodando enquanto o Arduino estiver ligado. Quando executa a última instrução dentro das chaves {}, começa tudo de novo pela primeira instrução, e fica assim repetindo até o Arduino ser desligado.
